using System;

namespace PCE_StarterProject
{
    class Program
    {
        static void Main(string[] args)
        {
            // This code is used by the first exercise
            // It is left here, uncommented, so that it's easy for you to run
            // Once you complete it, feel free to comment these lines out
            // That way, you won't have every single exercise being run, each and
            // every time :)

            Basic_Console_IO bcio = new Basic_Console_IO();
            bcio.RunExercise(); // you will need to uncomment this line!

            // The two lines of code below are used by the next exercise.
            // When you decide to do that exercise, you'll need to uncomment
            // these two lines.
            Basic_Arithmetic_Operators bao = new Basic_Arithmetic_Operators();
            bao.RunExercise();

            // Similarly, you'll need to uncomment these lines...
            Comparison_Operators co = new Comparison_Operators();
            co.RunExercise();

            Define_An_Instance_Method daim = new Define_An_Instance_Method();
            daim.RunExercise();

            HelloPrinter hp = new HelloPrinter();
            hp.printHello();

            NumberPrinter np = new NumberPrinter();
            np.printTwoNumbers();

            Data_Type_Explanations dte = new Data_Type_Explanations();
            dte.RunExercise();
        }
    }

    class Basic_Console_IO
    {
        public void RunExercise()
        {
            Console.WriteLine("Hello, World!");
        }
    }

    class Basic_Arithmetic_Operators
    {
        public void RunExercise()
        {
            {
                int x = 2, y = 8, z;

                Console.WriteLine("2 times 8 equals " + x * y);	// multiply
                Console.WriteLine("8 divided by 2 equals " + y / x);	// divide
                Console.WriteLine("8 mod 2 equals " + y % x);		// modulus
                Console.WriteLine("2 plus 8 equals " + (x + y));	// add
                Console.WriteLine("8 minus 2 equals " + (y - x));	// subtract

                z = ((y - (2 * x)) * 6) / 12;
                Console.WriteLine("z now equals " + z);
            }
        }
    }

    class Comparison_Operators
    {
        public void RunExercise()
        {
            Console.WriteLine("Get 2 integers & store them, then compare them using <, <=, etc, etc");
        }
    }

    class Define_An_Instance_Method
    {
        public void RunExercise()
        {
            Console.WriteLine("Hello, World, from the Instance Method Exercise!");
        }
    }

    public class HelloPrinter
    {
       public void printHello()
        {
            Console.WriteLine("Hello, World!");
        }
    }

    class NumberPrinter
    {
        public void printTwoNumbers()
        {
            Console.WriteLine("Please, type in 2 whole numbers.");
            string x;
            x = Console.ReadLine();
            string y;
            y = Console.ReadLine();
            int i;
            if (Int32.TryParse(x, out i) == true && Int32.TryParse(y, out i) == true)
            {
                Console.WriteLine("The number you typed is: {0} & {1}", x,y);
            } else
            {
                Console.WriteLine("You did not type in a whole number!");
            }

        }
    }

    class Data_Type_Explanations
    {
        public void RunExercise()
        {

            sbyte sb = -125;
            byte by = 254;
            short sh = -31768;
            ushort us = 32535;
            uint ui = 10000;
            long l = -15000;
            ulong ul = 15000;
            char ch = 'A'; 
            string a = "This is a string";
            int b = 1;
            double c = 3.1456789;
            float d = 4.256789f;
            decimal e = 5.36789m;
            bool z = true;

            Console.WriteLine("a: {0}",a);
            Console.WriteLine("big a: {0}",a.ToUpper());
            Console.WriteLine("small a: {0}",a.ToLower());
            Console.WriteLine("b: {0}",b);
            Console.WriteLine("c: {0:0.00} d:{1:0.00} e:{2:0.00}", c, d, e);

            Console.WriteLine("sb: {0}",sb);
            Console.WriteLine("by: {0}",by);
            Console.WriteLine("sh: {0}",sh);
            Console.WriteLine("us: {0}",us);
            Console.WriteLine("ui: {0}",ui);
            Console.WriteLine("l: {0}",l);
            Console.WriteLine("ul: {0}",ul);
            Console.WriteLine("ch: {0}",ch);
            Console.WriteLine("z: {0}",z);

        }
    }
    // Put the Data_Type_Explanations stuff here

    //A. MAXIMUM AND MINIMUM VALUE:
    // - sbyte: -128 to 127 (Signed 8-bit integer)
    // - byte: 0 to 255 (Unsigned 8-bit integer)
    // - short: -32,768 to 32,767 (Signed 16-bit integer)
    // - ushort: 0 to 65,535 (Unsigned 16-bit integer)
    // - int: -2,147,483,648 to 2,147,483,648 (Signed 32-bit integer)
    // - uint: 0 to 4,294,967,295 (Unsigned 32-bit integer)
    // - long: -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807 (Signed 64-bit integer)
    // - ulong: 0 to 18,446,744,073,709,551,615 (Unsigned 64-bit integer)
    // - char: U+0000 to U+FFFF (Unicode 16-bit character)
    // - float: -3.4 x 10^38 to +3.4 x 10^38 GAME (7 digits precision)
    // - double: (+/-) 5.0 x 10^(-324) to (+/-) 1.7 x 10^(308) (15-16 digits precision)
    // - decimal (-7.9 x 10^28 to 7.9 x 10^28) / (10^(0 to 28)) (28-29 significant digits)
    // - bool: true or false (1 byte)
    // - string: no maximum or minimum.
    
    // Smallest to Biggest Size
    // bool < sbyte = byte < short = ushort = char < int = uint = float < long = ulong = double < decimal < string


    //B. PREFIX U MEANS:
    // The prefix U means "Unsign", so for example, uint is the unsigned version of int.
    // It only contains positive numbers.

    //C. DIFFERENCES FLOAT, DOUBLE, DECIMAL. WHEN TO USE DECIMAL:
    //   Double has higher precision than float, and float has higher precision than decimal.
    //   Decimal has higher degree of accuracy.
     
    // - When we need the number to be really accurate instead of precise, for example:
    //   if we are talking about Money with currency.

    //D. ANSWERS TO QUESTIONS:
    //1. I will use Int, since a number of student will always be a whole number.
    //2. For tuition, I will use Decimal, to be more accurate.
    //3. For scientific computation, I will use Double, to have more precision.
    //4. Since it is 9 digits, I'll use Decimal.
    //5. I will use Bool, because it requires only 2 types of values, which can be represented by true and false.
    //6. I will use String, because it enables me to use any characters. 


    class Order_Of_Operations
    {
        //DONE SEPARATELY.
    }
}
